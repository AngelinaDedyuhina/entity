﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace enttiy
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            
       
            using (Model1Container users = new Model1Container())
            {
                // создаем два объекта User
                user user1 = new user { userName = "Tom", userAge = 33 };
                user user2 = new user { userName = "Sam", userAge = 26 };
               
                users.userSet.Add(user1);
                users.userSet.Add(user2);
                users.SaveChanges();

                
                grid.ItemsSource = users.userSet.ToList();
                
                
            }
        }

       
    }
}
   