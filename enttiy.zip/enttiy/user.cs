﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace enttiy
{
        public class user
        {
            public int id
            {
                get; set;
            }
            public string userName
            {
                get; set;
            }
            public int userAge
            {
                get; set;
            }
            
        }
    
}
